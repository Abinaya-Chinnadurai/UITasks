import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { HttpClientModule } from '@angular/common/http';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { ParentComponent } from './parent/parent.component';
import { ChildOneComponent } from './child-one/child-one.component';
import { ChildTwoComponent } from './child-two/child-two.component';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { LsOneComponent } from './ls-one/ls-one.component';
import { LsTwoComponent } from './ls-two/ls-two.component';
import { ServiceFileService } from './service-file.service';
import { ArrayStorageComponent } from './array-storage/array-storage.component';
import { ArrayStorageTwoComponent } from './array-storage-two/array-storage-two.component';
import { UserComponent } from './user/user.component';
import { ProbsComponent } from './probs/probs.component';

@NgModule({
  declarations: [
    AppComponent,
    ParentComponent,
    ChildOneComponent,
    ChildTwoComponent,
    LsOneComponent,
    LsTwoComponent,
    ArrayStorageComponent,
    ArrayStorageTwoComponent,
    UserComponent,
    ProbsComponent
  ],
  imports: [
    BrowserModule,
    HttpClientModule,
    AppRoutingModule,
    ReactiveFormsModule,
    FormsModule
  ],
  providers: [
    ServiceFileService
  ],
  bootstrap: [AppComponent]
})
export class AppModule { }
