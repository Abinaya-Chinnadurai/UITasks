import { Component, OnInit } from '@angular/core';
import { Observable } from 'rxjs';
import { filter} from 'rxjs/operators'

@Component({
  selector: 'app-probs',
  templateUrl: './probs.component.html',
  styleUrls: ['./probs.component.css']
})
export class ProbsComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {

    const promise = new Promise( resolve => {
      resolve('PromiseOne')
      resolve('PromiseTwo')
    })

    promise.then(res => {
      setTimeout(() => {
        console.log(res)
      }, 1000);
    })

    const obs = new Observable(observe => {
      observe.next('ObservableOne')
      setTimeout(() => {
        observe.next('ObservableTwo')
      }, 1000);
      observe.next('ObservableThree')
      observe.next('100')
    })

     obs.subscribe(res => {
       console.log(res)
     })

    obs.pipe(filter(res =>(res === '100'))).subscribe(res => {
      setTimeout(() => {
        console.log(res)
      }, 1000);
         
       }
    )
    
  }

}
