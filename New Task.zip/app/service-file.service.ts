import { Injectable } from '@angular/core';
import { BehaviorSubject, Subject, Observable} from 'rxjs';
import { HttpClient } from '@angular/common/http';
import { map } from 'rxjs/operators';
import { IUser } from './iuser';


@Injectable({
  providedIn: 'root'
})
export class ServiceFileService {

  public SubjectData = new Subject<string>();
  public BehaviorData = new BehaviorSubject('Hello!')

  constructor(private http : HttpClient) { }

  sendSubjectData(data : string){
     this.SubjectData.next(data)
  }

  sendBehaviorData(data : string){
    this.BehaviorData.next(data)
 }

 getUsers() : Observable<any>{
   return this.http.get("http://localhost:3000/users")
   .pipe(map(res=>res))
 }

 searchUser(id : number) : Observable<IUser>{
  return this.http.get("http://localhost:3000/users/"+id)
  .pipe(map((res:any)=>{
    return res;
  }))
}

 addData(record: any)  {
  return this.http.post<any>("http://localhost:3000/users/",record)
  .pipe(map((res:any)=>{
    return res;
  }))
}

editData(record: any,id : number)  {
  return this.http.put<any>("http://localhost:3000/users/"+id,record)
  .pipe(map((res:any)=>{
    return res;
  }))
}

deleteData(id : any)  {
  return this.http.delete<any>("http://localhost:3000/users/"+id)
  .pipe(map((res:any)=>{
    return res;
  }))
}

patchData(record: any,id : number)  {
  return this.http.patch<any>("http://localhost:3000/users/"+id,record)
  .pipe(map((res:any)=>{
    return res;
  }))
}


}
