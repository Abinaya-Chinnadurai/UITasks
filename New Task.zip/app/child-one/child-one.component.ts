import { Component, EventEmitter, Input, OnInit, Output } from '@angular/core';

@Component({
  selector: 'app-child-one',
  templateUrl: './child-one.component.html',
  styleUrls: ['./child-one.component.css']
})
export class ChildOneComponent implements OnInit {

  @Input() msgFromParent : string
  @Input() msgFromSibling : string

  @Output() frmChildOne = new EventEmitter();
  @Output() msgFrmChildOne = new EventEmitter();

  msgToParent:string
  msgToSibling:string
  

  constructor() { }

  ngOnInit(): void {
  }

  sendToParent(){
    this.frmChildOne.emit(this.msgToParent)
  }

  msgToChildTwo(){
    this.msgFrmChildOne.emit(this.msgToSibling);
  }

}
