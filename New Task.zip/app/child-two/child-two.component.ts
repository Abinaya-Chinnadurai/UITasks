import { Component, EventEmitter, Input, OnInit, Output } from '@angular/core';

@Component({
  selector: 'app-child-two',
  templateUrl: './child-two.component.html',
  styleUrls: ['./child-two.component.css']
})
export class ChildTwoComponent implements OnInit {

  @Input() msgFromParent : string
  @Input() msgFromSibling : string

  @Output() frmChildTwo = new EventEmitter();

  msgToParent:any
  msgFrmChildTwo :any=[]
  msgToSibling : any

  constructor() { }

  ngOnInit(): void {
  }

  sendToParent(){
    this.msgFrmChildTwo.push(this.msgToParent);
  }

  msgToChildOne(){
    this.frmChildTwo.emit(this.msgToSibling)
  }

}

