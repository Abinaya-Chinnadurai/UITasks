import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ArrayStorageTwoComponent } from './array-storage-two.component';

describe('ArrayStorageTwoComponent', () => {
  let component: ArrayStorageTwoComponent;
  let fixture: ComponentFixture<ArrayStorageTwoComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ ArrayStorageTwoComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(ArrayStorageTwoComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
