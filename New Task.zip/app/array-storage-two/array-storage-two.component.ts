import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-array-storage-two',
  templateUrl: './array-storage-two.component.html',
  styleUrls: ['./array-storage-two.component.css']
})
export class ArrayStorageTwoComponent implements OnInit {
 
  lsArr : any = []
  ssArr : any = []

  constructor() {
    this.lsArr.push(JSON.parse(localStorage.getItem("lsArray")))
    this.ssArr.push(JSON.parse(sessionStorage.getItem("ssArray")))
   }

  ngOnInit(): void {
  }

  delete(){
    localStorage.removeItem("lsArray")
    sessionStorage.removeItem("ssArray")
  }

  clear(){
    localStorage.clear()
    sessionStorage.clear()
  }

}
