import { Component, OnInit } from '@angular/core';
import { ServiceFileService } from '../service-file.service';

@Component({
  selector: 'app-ls-one',
  templateUrl: './ls-one.component.html',
  styleUrls: ['./ls-one.component.css']
})
export class LsOneComponent implements OnInit {

  data:string
  subject:string
  behavior:string

  constructor(private service : ServiceFileService) {
    this.service.SubjectData.subscribe(d =>{
      this.subject=d
    })
    this.service.BehaviorData.subscribe(d =>{
      this.behavior=d
    })
   }

  ngOnInit(): void {
  }

  storeData(){
    localStorage.setItem("lsData",this.data)
    sessionStorage.setItem("ssData",this.data)
  }

}
