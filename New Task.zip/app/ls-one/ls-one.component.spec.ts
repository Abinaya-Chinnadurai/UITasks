import { ComponentFixture, TestBed } from '@angular/core/testing';

import { LsOneComponent } from './ls-one.component';

describe('LsOneComponent', () => {
  let component: LsOneComponent;
  let fixture: ComponentFixture<LsOneComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ LsOneComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(LsOneComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
