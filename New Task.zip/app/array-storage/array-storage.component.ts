import { Component, OnInit } from '@angular/core';
import { FormBuilder } from '@angular/forms';
import { ServiceFileService } from '../service-file.service';

@Component({
  selector: 'app-array-storage',
  templateUrl: './array-storage.component.html',
  styleUrls: ['./array-storage.component.css']
})
export class ArrayStorageComponent implements OnInit {

  storageForm = this.fb.group({
    name:[''], age:[''],place:['']
  })

  arrData : any = []
  subject:string
  behavior:string

  constructor(private fb : FormBuilder, private service : ServiceFileService) {
    this.service.SubjectData.subscribe(d =>{
      this.subject=d
    })
    this.service.BehaviorData.subscribe(d =>{
      this.behavior=d
    })
   }

  ngOnInit(): void {
  }

  storeArray(){
    this.arrData = this.storageForm.value
    localStorage.setItem("lsArray",JSON.stringify(this.arrData))
    sessionStorage.setItem("ssArray",JSON.stringify(this.arrData))
  }

}


