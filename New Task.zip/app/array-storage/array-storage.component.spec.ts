import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ArrayStorageComponent } from './array-storage.component';

describe('ArrayStorageComponent', () => {
  let component: ArrayStorageComponent;
  let fixture: ComponentFixture<ArrayStorageComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ ArrayStorageComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(ArrayStorageComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
