import { Component, OnInit } from '@angular/core';
import { FormBuilder } from '@angular/forms';
import { Observable } from 'rxjs';
import { IUser } from '../iuser';
import { ServiceFileService } from '../service-file.service';

@Component({
  selector: 'app-user',
  templateUrl: './user.component.html',
  styleUrls: ['./user.component.css']
})
export class UserComponent implements OnInit {

  crudForm = this.fb.group({
    id : [],
    name : [''],
    email : [''],
    contact : ['']
  })

  editForm = this.fb.group({
    id : [],
    name : [''],
    email : [''],
    contact : ['']
  })

  patchForm = this.fb.group({
    id : [],
    name : [''],
    email : [''],
    contact : ['']
  })

  searchForm = this.fb.group({id : [] })

  users : IUser[]
  user : Observable<IUser>
  id : number

  constructor(private us : ServiceFileService, private fb : FormBuilder ) { 
    this.showData();
  }

  showData(){
    this.us.getUsers().subscribe(res => {
      this.users = res;
    });
  }

  addData(){
   this.us.addData(this.crudForm.value).subscribe();
   this.crudForm.reset();
   this.showData();
  }

 deleteData(value : any){
  if(confirm("Are you sure to delete?")){
    this.us.deleteData(value.id).subscribe();
    this.showData();
  }
 }

 editData(value : any){
   this.editForm.patchValue({
     id:value.id,
     name:value.name,
     contact:value.contact,
     email : value.email
   });
 }

 patchData(value : any){
  this.patchForm.patchValue({
    id:value.id,
    name:value.name,
    contact:value.contact,
    email : value.email
  });
}

 patchUser(){
  this.us.patchData( this.patchForm.value , this.patchForm.get('id')?.value ).subscribe();
  this.patchForm.reset();
  this.showData();
 }

 editUser(){
  this.us.editData( this.editForm.value , this.editForm.get('id')?.value ).subscribe();
  this.editForm.reset();
  this.showData();
 }

 searchUser(){
  this.user = this.us.searchUser(this.id);
 }

  ngOnInit(): void {

   }

}
