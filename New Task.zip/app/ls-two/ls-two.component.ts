import { Component, OnInit } from '@angular/core';
import { ServiceFileService } from '../service-file.service';

@Component({
  selector: 'app-ls-two',
  templateUrl: './ls-two.component.html',
  styleUrls: ['./ls-two.component.css']
})
export class LsTwoComponent implements OnInit {

  lsData:string
  ssData:string
  data:string

  constructor(private service : ServiceFileService) {
    this.lsData = localStorage.getItem("lsData")
    this.ssData = sessionStorage.getItem("ssData")
   }

  ngOnInit(): void {
  }

  sendToSubject(){
    this.service.sendSubjectData(this.data)
  }

  sendToBehavior(){
    this.service.sendBehaviorData(this.data)
  }

}

