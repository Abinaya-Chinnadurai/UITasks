import { ComponentFixture, TestBed } from '@angular/core/testing';

import { LsTwoComponent } from './ls-two.component';

describe('LsTwoComponent', () => {
  let component: LsTwoComponent;
  let fixture: ComponentFixture<LsTwoComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ LsTwoComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(LsTwoComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
