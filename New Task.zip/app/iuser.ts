export interface IUser {
    id : number,
    name:string,
    email:string,
    contact:string
}
