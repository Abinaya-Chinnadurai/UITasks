import { AfterViewInit, ChangeDetectorRef, Component, OnInit, ViewChild } from '@angular/core';
import { FormBuilder } from '@angular/forms';
import { ChildOneComponent } from '../child-one/child-one.component';
import { ChildTwoComponent } from '../child-two/child-two.component';

@Component({
  selector: 'app-parent',
  templateUrl: './parent.component.html',
  styleUrls: ['./parent.component.css']
})
export class ParentComponent implements OnInit, AfterViewInit{

  parentForm = this.fb.group({
    parentMessage:['']
  })

  @ViewChild(ChildTwoComponent) msgFromChildTwo : ChildTwoComponent

  msgToChildOne : string
  msgToChildTwo : string
  msgFrmChildOne : string
  msgFrmChildTwo : any
  msgFrmChildOneToChildTwo : any
  msgFrmChildTwoToChildOne : any

  constructor(private fb : FormBuilder,private cd : ChangeDetectorRef) { }

  ngAfterViewInit(): void {
    this.msgFrmChildTwo = this.msgFromChildTwo.msgFrmChildTwo;
    this.cd.detectChanges();
  }

  ngOnInit(): void {
  }

  parentMsgToChildOne(){
    this.msgToChildOne = this.parentForm.get('parentMessage')?.value;
    this.parentForm.reset();
  }

  parentMsgToChildTwo(){
    this.msgToChildTwo = this.parentForm.get('parentMessage')?.value;
    this.parentForm.reset();
  }

  parentMsgToChildren(){
    this.msgToChildOne = this.parentForm.get('parentMessage')?.value;
    this.msgToChildTwo = this.parentForm.get('parentMessage')?.value;
    this.parentForm.reset();
  }

  msgFromChildOne($event : string){
   this.msgFrmChildOne = $event
  }

  msgFromChildOneToChildTwo($event : string){
    this.msgFrmChildOneToChildTwo = $event
  }

  msgFromChildTwoToChildOne($event : string){
    this.msgFrmChildTwoToChildOne = $event
  }

}
