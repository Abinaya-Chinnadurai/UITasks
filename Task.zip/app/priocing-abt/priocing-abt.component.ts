import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-priocing-abt',
  templateUrl: './priocing-abt.component.html',
  styleUrls: ['./priocing-abt.component.css']
})
export class PriocingAbtComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
