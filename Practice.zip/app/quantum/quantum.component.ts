import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-quantum',
  templateUrl: './quantum.component.html',
  styleUrls: ['./quantum.component.css']
})
export class QuantumComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
