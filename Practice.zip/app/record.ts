export class Record {

	public firstname : string;
	public lastname: string;
	public email: string;
	public phone: string;
	public username: string;
    public password: string;

    constructor(){}
}
