import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { JsonServiceService } from '../json-service.service';

@Component({
  selector: 'app-table',
  templateUrl: './table.component.html',
  styleUrls: ['./table.component.css']
})
export class TableComponent implements OnInit {


  records : any
  constructor(private _jsonservice : JsonServiceService,private _router : Router) { 
    this.records = this._jsonservice.showData().subscribe(res=>{
      this.records = res;
    });
  }
 
public deleteData(value : any){
  this._jsonservice.deleteData(value.id).subscribe(res=>{
    alert("Record Deleted")
    this.records = this._jsonservice.showData().subscribe(res=>{
      this.records = res;
    });
  });
}
 

public editData(value : any){
  this._router.navigate(['/edit'])
}
  ngOnInit(): void {
  }

}
