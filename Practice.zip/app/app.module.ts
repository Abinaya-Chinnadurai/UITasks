import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { RegisterComponent } from './register/register.component';
import { RouterModule,Routes } from '@angular/router';
import { TableComponent } from './table/table.component';
import { HttpClient, HttpClientModule } from '@angular/common/http';
import { EditComponent } from './edit/edit.component';
import { FooterComponent } from './footer/footer.component';
import { QuantumComponent } from './quantum/quantum.component';


const appRoutes : Routes = 
[

  {path:'',component:RegisterComponent},
  {path:'register',component:RegisterComponent},
  {path:'table',component:TableComponent},
  {path:'edit',component:EditComponent},
]

@NgModule({
  declarations: [
    AppComponent,
    RegisterComponent,
    TableComponent,
    EditComponent,
    FooterComponent,
    QuantumComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    ReactiveFormsModule,
    FormsModule,
    HttpClientModule,
    RouterModule.forRoot(appRoutes)
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
