import { Component, OnInit } from '@angular/core';
import { FormBuilder} from '@angular/forms';
import { Router } from '@angular/router';
import { JsonServiceService } from '../json-service.service';
import { Record } from '../record';

@Component({
  selector: 'app-register',
  templateUrl: './register.component.html',
  styleUrls: ['./register.component.css']
})
export class RegisterComponent implements OnInit {

  registerForm = this.formbuilder.group({
    firstname:[''],
    lastname:[''],
    email:[''],
    phone:[''],
    username:[''],
    password:['']
    })

    record : Record = new Record
  
    constructor(private _router:Router,private formbuilder:FormBuilder,private _jsonservice :JsonServiceService ) { }
  
    addData(){
      this.record.firstname = this.registerForm.value.firstname;
      this.record.lastname = this.registerForm.value.lastname;
      this.record.email = this.registerForm.value.email;
      this.record.phone = this.registerForm.value.phone;
      this.record.username = this.registerForm.value.username;
      this.record.password = this.registerForm.value.password;

      this._jsonservice.addData(this.record).subscribe(res => {
        console.log(res);
        alert("Registration Successful!");
        this.registerForm.reset()
        this._router.navigate(['/table'])
      });
    
    }
    ngOnInit(): void {
      console.log();
    }

  // public arrayData:any=[];

  // public delete(i:number){
  //   this.arrayData.splice(i,1);
  // }

  // public edit(fname:string){
  //   this.registerForm.patchValue({
  //     firstname:fname
  //   })
    
  // }


  // public addData(){
  //   this.arrayData.push(this.registerForm.value);
  //   console.log(this.arrayData,this.registerForm.value);
  //   this.registerForm.reset()
  // }
  
  get firstname(){
    return this.registerForm.get('firstname')
  }
  get lastname(){
    return this.registerForm.get('lastname')
  }
  get email(){
    return this.registerForm.get('email')
  }
  get phone(){
    return this.registerForm.get('phone')
  }
  get username(){
    return this.registerForm.get('username')
  }
  get password(){
    return this.registerForm.get('password')
  }

  patchvalue(){
    this.registerForm.patchValue({
      firstname: 'Alice',
      lastname: 'Bob',
      email: 'email@gmail.com',
      phone: '+91 9874563210',
      username:'username',
      password:'password'
    })
  }
  
 

}
