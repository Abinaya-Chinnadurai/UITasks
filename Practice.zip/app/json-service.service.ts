import { Injectable } from '@angular/core';
import {HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { map } from 'rxjs/operators';
import { Record } from './record';

@Injectable({
  providedIn: 'root'
})
export class JsonServiceService {

  constructor(private _http : HttpClient) { }

  addData(record: any)  {
    return this._http.post<any>("http://localhost:3000/posts/",record)
    .pipe(map((res:any)=>{
      return res;
    }))
  }

  editData(record: any,id : any)  {
    return this._http.put<any>("http://localhost:3000/posts/"+id,record)
    .pipe(map((res:any)=>{
      return res;
    }))
  }

  showData()  {
    return this._http.get<any>("http://localhost:3000/posts/")
    .pipe(map((res:any)=>{
      return res;
    }))
  }

  deleteData(id : any)  {
    return this._http.delete<any>("http://localhost:3000/posts/"+id)
    .pipe(map((res:any)=>{
      return res;
    }))
  }

}
