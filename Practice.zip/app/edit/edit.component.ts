import { Component, OnInit } from '@angular/core';
import { FormBuilder,Validators} from '@angular/forms';

@Component({
  selector: 'app-edit',
  templateUrl: './edit.component.html',
  styleUrls: ['./edit.component.css']
})
export class EditComponent implements OnInit {

  public arrayData:any=[];
  editindex : number

  registerForm = this.formbuilder.group({
    firstname:[''],
    lastname:[''],
    email:[''],
    phone:[''],
    username:[''],
    password:['']
    })

    get firstname(){
      return this.registerForm.get('firstname')
    }
    get lastname(){
      return this.registerForm.get('lastname')
    }
    get email(){
      return this.registerForm.get('email')
    }
    get phone(){
      return this.registerForm.get('phone')
    }
    get username(){
      return this.registerForm.get('username')
    }
    get password(){
      return this.registerForm.get('password')
    }

  
  constructor(private formbuilder:FormBuilder) { }

  ngOnInit(): void {
   console.log();
  }

  patchvalue(){
    this.registerForm.patchValue({
      firstname: 'Alice',
      lastname: 'Bob',
      email: 'email@gmail.com',
      phone: '+91 9874563210',
      username:'username',
      password:'password'
    })
  }

  public addData(){
    this.arrayData.push(this.registerForm.value);
    console.log(this.arrayData,this.registerForm.value);
    this.registerForm.reset()
  }
  
  public delete(i:number){
    this.arrayData.splice(i,1);
  }
  
  
  public edit(value:[],i:number){ 
    this.registerForm.patchValue(value)
    this.editindex = i
  }
  
  public editData(){
    this.arrayData[this.editindex].firstname= this.registerForm.value.firstname
    this.arrayData[this.editindex].lastname= this.registerForm.value.lastname
    this.arrayData[this.editindex].email= this.registerForm.value.email
    this.arrayData[this.editindex].phone= this.registerForm.value.phone
    this.arrayData[this.editindex].username= this.registerForm.value.username
    this.arrayData[this.editindex].password= this.registerForm.value.password
    this.registerForm.reset()
  }

}
