import { Component, OnInit } from '@angular/core';
@Component({
  selector: 'app-content',
  template: '<app-about-us></app-about-us>',
  styleUrls: ['./content.component.css']
})
export class ContentComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {

  }

}



