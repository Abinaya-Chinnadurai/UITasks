import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-pricing-abt',
  templateUrl: './pricing-abt.component.html',
  styleUrls: ['./pricing-abt.component.css']
})
export class PricingAbtComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
